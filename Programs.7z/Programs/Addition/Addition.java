import java.util.Scanner;

public class Addition
{
   int a;
   int b;
   
   public static void main(String[] args)
    {
		Scanner sc= new Scanner(System.in);
           
       System.out.println("Enter First parameter - ");
       String s1=sc.nextLine();
       //int a= Integer.parseInt(args[0]);
          
      //int b= Integer.parseInt(args[1]);
      
       //int c= a+b;
      System.out.println("Addition is "+ s1);
    }
}