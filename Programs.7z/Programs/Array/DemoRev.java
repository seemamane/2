import java.util.Scanner;

public class DemoRev
{
 public static void main(String[] args)
 {
   final int SIZE=4;
   int sum=0;
   int [] myarr = new int[SIZE];
   Scanner sc=  new Scanner (System.in);
   System.out.println("Enter Array element");
   for(int i=0; i<SIZE;i++)
   {
       myarr [i] = sc.nextInt();  
   }  
   
   for(int i=0; i<SIZE; i++)
  {
    if(i/2==0)
	{
	System.out.println("Even"+myarr[i]);
	}
  }
   for(int i=0; i<SIZE; i++)
  {
     sum= sum+myarr[i];
	 System.out.println("Sum is "+sum);
  }

  
  
   for(int i=myarr.length-1; i>=0;i--)
   {
    System.out.println("Reverse No are -"+ myarr[i]);
   }
   
  }
 }
   