public class DemoAdditionOfMatrix
{
  public static void main(String[] args)
  {
  int i,j;
   int[][] matrix1= {{1,2,3},{5,6,7},{8,9,10}};
   int[][] matrix2= {{1,2,3},{5,6,7},{8,9,10}};
   int [][] total= new int[3][3];
   for( i=0; i<3; i++)
   {
    for( j=0;j<3;j++)
	{
	  total[i][j]= matrix1[i][j]+ matrix2[i][j];
    }
	  
   }
   for( i=0; i<3; i++)
   {
    for( j=0;j<3;j++)
	{
       System.out.print(total[i][j]+"\t");	
	}
	System.out.println();
}
	  }
	  }