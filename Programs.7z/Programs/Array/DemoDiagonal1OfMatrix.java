public class DemoDiagonal1OfMatrix
{
public static void main(String[] args)
  {
    int i,j;
	//int [][] temp = new int[3][3];
   int[][] matrix1= {{1,2,3},{4,5,6,},{7,8,9}};
   //int[][] matrix2= {{1,2,3},{5,6,7},{8,9,10}};
 //  int [][] total= new int[3][3];
   for( i=0; i<3;i++)
   {
    for( j=0; j>i;j++)
	{
	  System.out.print(matrix1[i][j]+"\t");
	 }
	  System.out.println();
	  }
	  }
	  }