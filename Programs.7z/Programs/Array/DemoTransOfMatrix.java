public class DemoTransOfMatrix
{
  public static void main(String[] args)
  {
    int i,j;
	int [][] temp = new int[3][3];
   int[][] matrix1= {{1,2,3},{4,5,6,},{7,8,9}};
   //int[][] matrix2= {{1,2,3},{5,6,7},{8,9,10}};
   int [][] total= new int[3][3];
   for( i=0; i<3;i++)
   {
    for( j=0; j<3;j++)
	{
	
    
	//matrix1[i][j]=matrix1[j][i];
	temp[i][j]= matrix1[j][i];
	//matrix1[j][i]=temp[i][j];
	 
	  System.out.print(temp[i][j]+"\t");
	 }
	// matrix1[i][j]=0;
   }
   
   /*for( i=0; i<3;i++)
   {
    for( j=0; j<3;j++)
	{
	  System.out.print(temp[i][j]+"\t");
	  
	 }
	 System.out.println();
	 }*/
	 }
	 }