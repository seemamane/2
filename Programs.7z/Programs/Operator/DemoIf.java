public class DemoIf
{
 public static void main(String[] args)
 {
   int a=2,b=3,c=4;
   if(a>b && a>c)
     {
      System.out.println("a is Greater");
     }
    else if(b>a && b>c)
    {
     System.out.println("b is greater");
    } 
     else
       { System.out.println("c");
}}
}