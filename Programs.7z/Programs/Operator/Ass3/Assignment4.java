public class Febonicce
{
public static void main(String[] args)
{
  int num1=0,num3, num2=1,i;
  System.out.println(num1);
  System.out.println(num2);
  for(i=2;i<20;++i)
  {
     num3=num1+num2;
    System.out.println(num3);
	num1=num2;
	num2=num3;
   }
	}
	}