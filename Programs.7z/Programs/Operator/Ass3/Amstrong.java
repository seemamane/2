public class Amstrong
{
public static void main(String[] args)
{
  int num1=153, num2, num3,temp;
  while(num1!=0)
  {
  num2= num1%10;
 temp= (num2)*(num2)*(num2);
  num3=num1/10;
  
  if (temp==num1)
  {System.out.println("Amstrong");
  }
  else
  {
  System.out.println("Non Amstrong");
  }
  }
  }
  }