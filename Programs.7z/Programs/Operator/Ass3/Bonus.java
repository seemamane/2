import java.util.Scanner;

public class Bonus
{
 public static void main(String[] args)
 {
   int sal;
   String name;
   
   Scanner sc=  new Scanner (System.in);
   System.out.println("Enter Your Name");
   name= sc.nextLine();
   
   System.out.println("Enter Your Salary");
   sal= sc.nextInt();
   
   
   if(sal> 2000000)
     {
      
      System.out.println("Bonus is 15%");
      
     }
    else if(sal>1000000 && sal<2000000)
    {
     System.out.println("Bonus is 20%");
    } 
     else if(sal>500000 && sal<1000000)
     {
      System.out.println("Bonus is 25%");
     }else
     {
      System.out.println("Bonus is 30%");
     }
   // System.out.println("Your Salary is -");
}
}