public class DemoFor
{
public static void main(String[] args)
{
int i=0,j=100;
//for(int i=1,j=50; i<=10;i++,j++)
for(;;)
{
 if (i==5)                            // Use of Break
   break;
System.out.println(i+ "====="+ j);
i++;
j++;

//num--;
}
System.out.println("Done");
}
}