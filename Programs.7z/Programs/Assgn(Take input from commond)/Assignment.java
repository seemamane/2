import java.util.Scanner;

public class Assignment
{

 public static void main (String args[])
  {
     
	int total;
	float avg;

Scanner sc= new Scanner(System.in);
System.out.println("Enter First Name-");
String fname= sc.nextLine();

System.out.println("Enter Last Name-");
String lname= sc.nextLine();


System.out.println("Enter Address Name-");
String addr= sc.nextLine();

System.out.println("Enter Mark of Maths-");
int math= sc.nextInt();

System.out.println("Enter Marks of java-");
int java= sc.nextInt();

System.out.println("Enter Marks of html-");
int html= sc.nextInt();

total= math+java+html;
System.out.println("Total of Marks are " + total);
avg= total/3;
System.out.println("Average is "+ avg);


}
}