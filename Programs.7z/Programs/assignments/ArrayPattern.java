import java.util.Scanner;
public class ArrayPattern
{
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		int m1,n1,i,j;
		System.out.println("enter size of  array:");
		m1=sc.nextInt();
		n1=sc.nextInt();
		
		int [][] myArr1=new int [m1][n1];
		if(m1==n1)
		{
		System.out.println("enter array:");
		for(i=0;i<m1;i++)
			for(j=0;j<n1;j++)
				myArr1[i][j]=sc.nextInt();
			
			for( i=0;i<m1;i++)
			{	for(j=0;j<n1;j++)
				{	
					System.out.print(" ");
					if(i+j>=m1-1)
						{
							
							System.out.print(myArr1[i][j]);
						  
						 }
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("\n");
			}
			for( i=0;i<m1;i++)
			{	for(j=0;j<n1;j++)
				{	
					if(i>=j)
						{
							System.out.print(myArr1[i][j]+ " ");
						  }
					else
					{
						System.out.print(" ");
					}
				}
				System.out.println("\n");
			}
		}	
	}
}