package flp.capgemini.demo;

import java.util.Scanner;

public class BookMain {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//Book book=new Book();
		BookDAOImplementation bookimp=new BookDAOImplementation();
		int option;
		do{
			System.out.println("1.Save Book");
			System.out.println("2.List all Books");
			System.out.println("3.Search Book");
			System.out.println("4.Delete Book");
			System.out.println("Enter your option");
			option=sc.nextInt();
			if(option==1)
			{ 
				Book book=new Book();
				book=book.getBookDetails();
				bookimp.saveBook(book);
								
			}
			else if(option==2)
			{
			
				bookimp.listAllBooks();
			}
			else if(option==3)
			{
				System.out.println("Enter book id");
				int bookId=sc.nextInt();
				bookimp.searchBook(bookId);
			}
			else if(option==4)
			{
				System.out.println("Enter book id");
				int bookId=sc.nextInt();
				bookimp.deleteBook(bookId);
			}
			else
			{
				System.out.println("Invalid Input");
			}
		}while(option==1||option==2||option==3||option==4);

	}

}
