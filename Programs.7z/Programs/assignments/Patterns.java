package org.capgemini.com;


	//import java.awt.Color;
import java.util.Scanner;

	public class Patterns
	{
		int number;
		public void getInput()
		{
			System.out.println("Enter Input:");
			Scanner sc=new Scanner(System.in);
			number=sc.nextInt();
			
		}
		public void computePattern()
		{
			int count=0;
			for(int i=1;i<=number;i=i+2)
			{
				System.out.print(i+" ");
				count++;
				if(count%3==0)
				{
					if(i%2==0)
					{
						i=i-1;
						//StyleConstants.setForeground(style, Color.BLUE);
					}
					else
				
					i=i-5;
				}
			}
			
			
			
		}
		
		
	}


