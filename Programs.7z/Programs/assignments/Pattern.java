package org.capgemini.com;


public class Pattern {

	public static void main(String[] args)
	{
		
		Patterns p=new Patterns();
		p.getInput();
		p.computePattern();

	}

}
