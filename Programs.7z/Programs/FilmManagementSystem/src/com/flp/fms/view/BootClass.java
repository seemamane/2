package com.flp.fms.view;

import java.util.Collection;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass {

	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int option,searchOption;
		String choice=null;
		String chr=null;
		UserInteraction userInteraction=new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		do{
		menuSelection();
		System.out.println("Enter your option:[1-6]");
		option=sc.nextInt();
		switch(option){
			case 1:
				Film film=userInteraction.addFilm(filmService.getLanguages(),filmService.getCategory(), actorService.getActors());
				filmService.addFilm(film);
				System.out.println(film);
				break;
			case 2:
				break;
			case 3:Map<Integer, Film>  film_lstr= filmService.getAllFilms();
				   Collection<Film> lstr=film_lstr.values();
				   userInteraction.removeFilm(lstr);
				break;
			case 4://do{
				
					System.out.println("1:Search By Film Id");
					System.out.println("2:Search By Film Title");
					System.out.println("3:Search By Rating");
					System.out.println("Enter your choice-->");
					searchOption=sc.nextInt();
					switch(searchOption){
					case 1:
						Map<Integer, Film>  film_lst= filmService.getAllFilms();
						Collection<Film> lst=film_lst.values();
						userInteraction.searchFilm(lst);
						break;
					case 2:
						Map<Integer, Film>  film_lstt= filmService.getAllFilms();
						Collection<Film> lstt=film_lstt.values();
						userInteraction.SearchByFilmTitle(lstt);
						break;
					case 3:
						Map<Integer, Film>  film_lstrt= filmService.getAllFilms();
						Collection<Film> lstrt=film_lstrt.values();
						userInteraction.SearchByRating(lstrt);
						break;
					//System.out.println("Do you Want to Search By Another Field?[Y|N]");
					//chr=sc.next();
					}
					//}while(chr.charAt(0)=='Y'||chr.charAt(0)=='y');
					break;
					
			case 5:
				Map<Integer, Film>  film_lst1= filmService.getAllFilms();
				Collection<Film> lst1=film_lst1.values();
				userInteraction.getAllFilm(lst1);
				break;
				
		}
		System.out.println("Do You Wish To Continue?[Y|N]");
		choice=sc.next();
		}while(choice.charAt(0)=='Y' || choice.charAt(0)=='y');

	}

	//Menu Selection
	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}
	
	


	}


