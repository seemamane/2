package com.flp.fms.util;

import java.util.Iterator;
import java.util.List;

import com.flp.fms.domain.Language;

public class Validate {

	//Validation for Title
	public static boolean isValidTitle(String title){
		return title.matches("[A-Za-z0-9.,! ]+");
	}

	//Validation for Date
	public static boolean isValiddate(String date){
		
		return date.matches("[0123]\\d{1}-(jan|feb|mar|apr|jun|jul|aug|sep|oct|dec)-[12][890]\\d{2}");
		
	}
	
	//Validation for Ratings
	public static boolean isValidRatings(int rating) {
		//boolean flag=false;
		if(rating>=1||rating<=5)
			return true;
		else 
			return false;
		
	}

	//Validation for Length
	public static boolean isValidLength(int length) {
		//boolean flag=false;
		if(length>=1||length<=1000)
			return true;
		else 
			return false;
	}

	
	//Validation for Special Features
	public static boolean isValidSpecialFeatures(String specilFeatures) {
		return specilFeatures.matches("[A-Za-z0-9.,! ]+");
	}
	
	//Validation for Duplicate Language
	public static boolean checkDuplicateLanguage(List<Language> languages2,Language language1) {
		boolean flag=false;
		
		Iterator<Language> it= languages2.iterator();
		if(languages2.isEmpty())
		{
			flag=false;
		}else{
				while(it.hasNext()){
					Language language2=it.next();
					if(language1.equals(language2))
					{
						flag=true;
						break;
					}
				}
		}
		return flag;
	}

	
	}
	

