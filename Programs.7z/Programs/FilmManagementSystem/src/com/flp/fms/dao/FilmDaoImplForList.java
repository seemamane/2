package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao{

	private Map<Integer, Film> film_repository=new HashMap<Integer, Film>();
	
	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marathi"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		
		
		return languages;
	}

	public List<Category> getCategory(){
		
		List<Category> category=new ArrayList<>();
		category.add(new Category(1, "Action"));
		category.add(new Category(2, "Comedy"));
		category.add(new Category(3, "Drama"));
		category.add(new Category(4, "Sci-Fi"));
		category.add(new Category(5, "Magic"));
				
		
		
		return category;
	}

	@Override
	public void addFilm(Film film) {
		
		film_repository.put(film.getFilmId(), film);
	}

	@Override
	public Map<Integer, Film> getAllFilms() {
	
		return film_repository;
	}
	
//	public Set getKeys(){
//		Set<Integer> keys= getAllFilms().keySet();
//		Iterator<Integer> it= keys.iterator();
//	
//		while(it.hasNext()){
//			Integer key= it.next();
//		System.out.println(film_repository.get(keys).toString());
//		
//		}
//		return keys;
//	}

}
