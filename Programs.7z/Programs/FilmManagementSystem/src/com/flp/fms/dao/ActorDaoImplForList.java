package com.flp.fms.dao;

import java.util.HashSet;
import java.util.Set;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao{

	@Override
	public Set<Actor> getActors() {
	
		Set<Actor> actors=new HashSet<Actor>();
		actors.add(new Actor(101,"Seema","Mane"));
		actors.add(new Actor(102,"Priya","Salunke"));
		actors.add(new Actor(103,"Priyanka","Chopra"));
		actors.add(new Actor(104,"Yuvraj","Singh"));
		actors.add(new Actor(105,"Shewta","Kokate"));
		actors.add(new Actor(106,"Jarin","Khan"));
		actors.add(new Actor(107,"Asin","Devgan"));
		actors.add(new Actor(108,"Kajol","Kapoor"));
		return actors;
	}

}
