package com.flp.fms.dao;

import java.util.Set;

import com.flp.fms.domain.Actor;

public interface IActorDao {

	public Set<Actor> getActors();
}
