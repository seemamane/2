package com.flp.fms.domain;

public class Category {

	//private fields
	private int category_Id;
	private String category_Name;
	
	//No argument Constructor
	public Category(){
		
	}
	
	//overloaded Constructor
	public Category(int category_Id, String category_Name){
		
		super();
		this.category_Id=category_Id;
		this.category_Name=category_Name;
		
	}
	
	//getters and setters 
	public int getCategory_Id() {
		return category_Id;
	}

	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}

	public String getCategory_Name() {
		return category_Name;
	}

	public void setCategory_Name(String category_Name) {
		this.category_Name = category_Name;
	}

	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", category_Name="
				+ category_Name + "]";
	}
	
	
	
}
