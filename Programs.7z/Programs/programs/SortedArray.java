import java.util.Scanner;

public class SortArray
{
   public static void main(String[] args)
   {
     Scanner sc=new Scanner(System.in);
	 
	 final int SIZE=5;
	 int temp,i,j;
	 
     int arr[]=new int[SIZE];
     System.out.println("Enter 5 elements");
	 for(int i=0;i<SIZE;i++)
     arr[i]=sc.nextInt();
	 
	 for(int i=0;i<SIZE;i++)
	 {  for(j=0;j<SIZE;j++)
	    {  if(arr(j+1)<arr(j))
		   {  temp=arr(j);
		      arr(j)=arr(j+1);
			  arr(j+1)=temp;
			}  
		}
	 }
	  
	 System.out.print("Sorted Array:");
	 for(int i=0;i<arr.length;i++)
	 System.out.print(arr[i]); 
	 }	
     	
}	
	