import java.util.Scanner;

public class SumofOddnEvenArray
{
   public static void main(String[] args)
   {
     Scanner sc=new Scanner(System.in);
	 
	 final int SIZE=5;
	 int oddSum=0,evenSum=0;
	 
     int arr[]=new int[SIZE];
     System.out.println("Enter 5 elements");
	 for(int i=0;i<SIZE;i++)
     arr[i]=sc.nextInt();
	 
	 for(int i=0;i<arr.length;i++)
	 {if(arr[i]%2!=0)
	 oddSum+=arr[i];
	 else
	 evenSum+=arr[i];
	 } 
	 System.out.println("Sum of odd nmbrs:" + oddSum);
	 System.out.println("Sum of even nmbrs:" + evenSum);
	}
}	
	