import java.util.Scanner;

public class Program1
{
     public static void main(String[] args)
     {
         String fName,lName,address;
         int java,servelet,html,total;
         float average;
        
     Scanner sc=new Scanner(System.in); 
    
     System.out.println("Enter first name:");
     fName=sc.next();

     System.out.println("Enter last name:");
     lName=sc.next();
     
     System.out.println("Enter address:");
     address=sc.next();

     System.out.println("Enter java marks:");
     java=sc.nextInt();

     System.out.println("Enter servelet marks:");
     servelet=sc.nextInt();

     System.out.println("Enter html marks:");
     html=sc.nextInt();

     total=java+servelet+html;
     System.out.println("Total:" + total);
     average=(total/3);
     System.out.println("Average:" + average);
    
     }
}

     

             