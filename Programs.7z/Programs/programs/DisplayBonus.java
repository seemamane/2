import java.util.Scanner;

public class DisplayBonus
{
     public static void main(String[] args)
     {
          String eName;
          int salary;
          double bonus;

          Scanner sc=new Scanner(System.in);
         
          System.out.println("Enter employee name");
          eName=sc.next();

          System.out.println("Enter salary");
          salary=sc.nextInt();

          if(salary>2000000)
             bonus=salary*.15;
        
          else if(salary>1000000)
             bonus=salary*.20;
 
          else if(salary>500000)
             bonus=salary*.25;

          else
             bonus=salary*.30;

          System.out.println("Bonus amount is:" + bonus);

      }
}
          
           

       