import java.util.Scanner;

public class Fibonacci
{
     public static void main(String[] args)
     {
	      int first=0,second=1,next,limit,i;
		  
		  Scanner sc=new Scanner(System.in);
		  
		  System.out.println("Enter the limit for fibonacci series");
		  limit=sc.nextInt();
		  
		  for(i=0;i<=limit;i++)
		  {
		    if(i<=1)
			next=i;
			
			else 
			
		    next=first+second;
		    first=second;
		    second=next;
			
			System.out.println("Fibonnacci series:" + next);
		  }	
     }	  
}		  
		  
		  