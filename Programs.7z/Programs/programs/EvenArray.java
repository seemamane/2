import java.util.Scanner;

public class EvenArray
{
   public static void main(String[] args)
   {
     Scanner sc=new Scanner(System.in);
	 
	 final int SIZE=5;
	 
     int arr[]=new int[SIZE];
     System.out.println("Enter 5 elements");
	 for(int i=0;i<SIZE;i++)
     arr[i]=sc.nextInt();
	 
	 System.out.print("Even elements:");
	 for(int i=0;i<arr.length;i++)
	 if(arr[i]%2==0)
	 System.out.print(arr[i]+"\t");
	 
	}
}	
	