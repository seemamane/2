import java.util.Scanner;

public class ReverseArray
{
   public static void main(String[] args)
   {
     Scanner sc=new Scanner(System.in);
	 
	 final int SIZE=5;
	 int i;
	 
     int arr[]=new int[SIZE];
     System.out.println("Enter 5 elements");
	 for(i=0;i<SIZE;i++)
     arr[i]=sc.nextInt();
	 
	 for(i=4;i>=0;i--)
	 {System.out.print(arr[i]+"\t");
	 }
	 System.out.println();
	 
	}
}	
	