package org.capgemini.demo;
import java.util.Scanner;

public class StudentService {

	Student[] students;
	
	public void initializeArray(int size) {
	    students=new Student[size];
	}
	 public void getStudents() {
		 int number;
		 
		 Scanner sc=new Scanner(System.in);
		 
		 System.out.println("Enter number of students:");
		 number=sc.nextInt();
		 
		 initializeArray(number);
        
		 for(int i=0;i<number;i++) {
			 students[i]=new Student();
			 students[i].getStudentDetails();
		 }
	}

	 
	 public void printStudents() {
		 
		 System.out.println("StudId\tFirstName\tLastName\tFees");
		 
		 for(int i=0;i<students.length;i++)
			 students[i].printStudentDetails();
	 
	 }
	 
	 public void sortFees() {
         Student temp=new Student();
         
		 for(int i=0;i<students.length;i++) {
		 for(int j=i+1;j<students.length;j++){	 
		 if((students[i].getStudentFees())>(students[j].getStudentFees())) {
			 temp=students[i];
			 students[i]=students[j];
			 students[j]=temp;
		 }}
		 }
	 }
}
	 



