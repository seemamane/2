package org.capgemini.demo;

public class ArrayDemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ArrayDemo arr=new ArrayDemo();
        
        arr.getArray();
        arr.reverseArray();
	}

}
