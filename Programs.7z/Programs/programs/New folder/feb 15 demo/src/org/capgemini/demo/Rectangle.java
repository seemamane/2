package org.capgemini.demo;

import java.util.Scanner;

public class Rectangle {
	double length;
	double width;
	double area;
	String color;
	public void set_length()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter length:");
		length=sc.nextDouble();
	}
	public void set_width()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter width:");
		width=sc.nextDouble();
	}
	public void set_color()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter color:");
		color=sc.next();
	}
	public double set_area()
	{
		area=length*width;
		return area;
    }
	public String get_color()
	{
		return color;
	}

}


