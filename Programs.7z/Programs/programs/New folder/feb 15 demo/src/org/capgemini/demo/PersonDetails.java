package org.capgemini.demo;

public class PersonDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person pers=new Person();
		pers.getPersonDetails();
		pers.calculateAvg();
		pers.printPersonDetails();

	}

}
