package org.capgemini.demo;
import java.util.Scanner;

public class Person {
	
	String name,address;
	int personId,c,cPlusPlus,java;
	
public void getPersonDetails() {
	
	Scanner sc=new Scanner(System.in); 
	
	System.out.println("Enter address:");
    address=sc.nextLine();
	
	System.out.println("Enter personId:");
    personId=sc.nextInt();
    
    System.out.println("Enter person name:");
    name=sc.next();
    
    System.out.println("Enter c marks:");
    c=sc.nextInt();
    
    System.out.println("Enter c++ marks:");
    cPlusPlus=sc.nextInt();
    
    System.out.println("Enter java marks:");
    java=sc.nextInt();
    
}

public float calculateAvg() {
	
	int total;
	float avg;
	
	total=c+cPlusPlus+java;
	avg=total/3;
	return avg;
	
}

public void printPersonDetails() {
	
	System.out.println("personId:" + personId);
	System.out.println("person name:" + name);
	System.out.println("person address:" + address);
	System.out.println("c marks:" + c);
	System.out.println("c++ marks:" + cPlusPlus);
	System.out.println("java marks:" + java);
	System.out.println("Average marks:" + calculateAvg());
	
}

}
	
	
	
	
	
	


