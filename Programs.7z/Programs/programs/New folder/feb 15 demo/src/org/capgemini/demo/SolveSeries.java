package org.capgemini.demo;

public class SolveSeries {

	public static void main(String[] args) {
	Series ser=new Series();
        ser.getInput();
        System.out.println(ser.sumOfSeries());
        
	}

}
