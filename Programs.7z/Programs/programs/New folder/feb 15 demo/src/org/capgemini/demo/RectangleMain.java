package org.capgemini.demo;

public class RectangleMain {

	public static void main(String[] args) {
		
		Rectangle r1=new Rectangle();
		Rectangle r2=new Rectangle();
		System.out.println("Enter details of first rectangle :");
		r1.set_color();
		r1.set_length();
		r1.set_width();
		
		System.out.println("Enter details of second rectangle :");
		r2.set_color();
		r2.set_length();
		r2.set_width();
		String r1color=r1.get_color();
		String r2color=r2.get_color();
		if(r2.set_area()==r1.set_area() && r1color.equals(r2color))
		{
			System.out.println("Matching rectangles :");
		}
		else
		{
			System.out.println("Not matching rectangles :");
		}

	}

}
