package org.capgemini.demo;
import java.util.Scanner;

public class ArrayDemo {
	int[] myArray;


public void initializeArray(int size) {
	myArray=new int[size];
}

public void getArray() {
	int size;
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter size of array:");
	size=sc.nextInt();
	
	initializeArray(size);
	
	System.out.println("enter elements of array:");
	for(int i=0;i<myArray.length;i++) {
		myArray[i]=sc.nextInt();
	}
	}
	
public void reverseArray() {
	
	for(int i=myArray.length-1;i>0;i--)
		System.out.println(myArray[i]);
}
		
	
	
	
}
