package org.capgemini.demo;

public class StackMain {

	public static void main(String[] args) {
		Stack s1=new Stack();
		Stack s2=new Stack();
		int i=10;
		s1.initialize();
		s2.initialize();
		System.out.println("Enter first stack :");
		s1.push();
		System.out.println("Enter second stack :");
		s2.push();
		while(i>0)
		{
			if(s1.pop()==s2.pop())
			{
				System.out.println("Similar");
			}
			else
			{
				System.out.println("Not similar");	
			}
			i--;
			}
		}
		

	}


