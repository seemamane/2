package org.capgemini.demo;
import java.util.Scanner;

public class Series {
	int num;
	double sum;
	
public void getInput() {
	
Scanner sc=new Scanner(System.in); 
	
	System.out.println("Enter number:");
    num=sc.nextInt();
}

public long findFactorial(int num) {
	int i;
	long fact=1;
	
	for(i=1;i<=num;i++) 
		fact= fact*i;
	
	return fact;
}

public long findPower(int base, int num) {
	long power=1;
	int i;
	
	for(i=1;i<=num;i++)
	    power=power*base;
	
		return power;
}

public double sumOfSeries() {
	int i;
	double sum=0;
	
	for(i=1;i<=num;i++) {
	  	sum=sum + ((float)findPower(i,i)/findFactorial(i));
	  	}
	  	return sum;
	    
		
	}
}


