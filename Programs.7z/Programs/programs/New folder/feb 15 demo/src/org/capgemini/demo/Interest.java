package org.capgemini.demo;
import java.util.Scanner;

public class Interest {
	double principle;
	float period,rate;
	
public void getInput() {
	Scanner sc=new Scanner(System.in); 
	
	System.out.println("Enter Principle:");
	principle=sc.nextDouble();
	
	System.out.println("Enter nummber of years:");
    period=sc.nextFloat();
    
    System.out.println("Enter rate of interest:");
    rate=sc.nextFloat();

}

public double findInterest() {
	return principle*period*rate;
}


	

}
