package org.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		
		StudentService stud=new StudentService();
		stud.getStudents();
		//stud.printStudents();
		stud.sortFees();
		stud.printStudents();

	}

}
