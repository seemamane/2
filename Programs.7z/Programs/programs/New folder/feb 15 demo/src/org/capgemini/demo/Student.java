package org.capgemini.demo;
import java.util.Scanner;

public class Student {
	private String firstName,lastName;
	private int studId;
	private double fees;
	
public void getStudentDetails() {
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter Student Id:");
	studId=sc.nextInt();
	
	System.out.println("Enter First Name:");
	firstName=sc.next();
	
	System.out.println("Enter Last Name:");
	lastName=sc.next();
	
	System.out.println("Enter fees:");
	fees=sc.nextDouble();
}

public void printStudentDetails() {
	System.out.println(studId+"  \t" + firstName+ "\t\t" + lastName +"\t\t" + fees);
	
}

public double getStudentFees() {
	return fees;
}

}
