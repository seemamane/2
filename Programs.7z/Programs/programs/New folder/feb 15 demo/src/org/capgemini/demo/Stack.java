package org.capgemini.demo;

import java.util.Scanner;

public class Stack {
	int size;
	int[] myArray;
	public void initialize()
	{
		size=10;
		myArray=new int[size];
	}
	public int pop() {
		size=size-1;
		int top=myArray[size];
		return(top);
	}
	public void push() {
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<10;i++)
			myArray[i]=sc.nextInt();
	}
	
}	


