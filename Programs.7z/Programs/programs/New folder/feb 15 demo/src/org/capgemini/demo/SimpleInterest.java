package org.capgemini.demo;

public class SimpleInterest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Interest inter=new Interest();
        inter.getInput();
        System.out.println(inter.findInterest());
	}
}
