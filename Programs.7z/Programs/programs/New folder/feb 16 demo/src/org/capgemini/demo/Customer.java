package org.capgemini.demo;
import java.util.Scanner;

public class Customer {
	private String custName;
	private int custId,regFees;
	//private Double regFees;
	private Address custAddress;
	
public Customer() {
	
	System.out.println("Default Customer");
	this.custId=1001;
	this.custName="Kiran";
	this.regFees=500;
	this.custAddress=new Address();
}

public Customer(int custId, String custName, int regFees, Address custAddress) {
	System.out.println("Overloaded Customer");
	this.custId=custId;
	this.custName=custName;
	this.regFees=regFees;
	this.custAddress=custAddress;
	
}

public void getCustomer() {
	
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter Customer Id:");
	custId=sc.nextInt();
	
	System.out.println("Enter Customer Name:");
	custName=sc.next();
	
	System.out.println("Enter reg fees:");
	regFees=sc.nextInt();
	
	System.out.println("Address:");
	custAddress.getAddress();
	
}
	
public void printCustomer() {
	
	System.out.println("Customer id:" + custId);
	System.out.println("Customer Name:" + custName);
	System.out.println("Reg Fees:" + regFees);
	System.out.println("Address:");
	custAddress.printAddress();
	
}

}
