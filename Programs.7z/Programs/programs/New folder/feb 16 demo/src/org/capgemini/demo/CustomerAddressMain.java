package org.capgemini.demo;

public class CustomerAddressMain {

	public static void main(String[] args) {
		
		Customer customer=new Customer(1002,"Kevin",1000,new Address());
		customer.printCustomer();
		customer.getCustomer();
		customer.printCustomer();

	}

}
