package org.capgemini.demo;
import java.util.Scanner;

public class Address {
	private String city,state;
	private int doorNo,streetNo,pinCode;
	
    public Address() {
		
		System.out.println("Default Address");
		this.doorNo=13;
		this.streetNo=1;
		this.city="Kochi";
		this.state="Kerala";
		this.pinCode=007;
	}

	public Address(int doorNo, int streetNo, String city, String state, int pinCode) {
		System.out.println("Overloaded Address");
		this.doorNo=doorNo;
		this.streetNo=streetNo;
		this.city=city;
		this.state=state;
		this.pinCode=pinCode;
		
	}

	public void getAddress() {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Door No:");
		doorNo=sc.nextInt();
		
		System.out.println("Enter Street No:");
		streetNo=sc.nextInt();
		
		System.out.println("Enter City:");
		city=sc.next();
		
		System.out.println("Enter State:");
		state=sc.next();
		
		System.out.println("Enter pinCode:");
		pinCode=sc.nextInt();
	}
		
	public void printAddress() {
		
		System.out.println("Door No:" + doorNo);
		System.out.println("Street No:" + streetNo);
		System.out.println("City:" + city);
		System.out.println("State:" + state);
		System.out.println("Pin Code:" + pinCode);
		
	}

		
}
