import java.util.Scanner;
 
class NumberToWord
{

public static void main(String[] args)
{
     int number,div=1000,temp=0,count=0;
	 
	 Scanner sc=new Scanner(System.in); 
	  
	 System.out.println("Enter 4 digit no:");
     number=sc.nextInt();
	 System.out.println("\nIn words:");
	 if(number==0)
	     System.out.println("Zero");
	 else
	 {
	 while(number!=0)
     {	 
             temp=number/div;
			 if(div==1000||div==100||div==1)
			 {
			         if(temp==1)
					 System.out.print("One ");
					 else if(temp==2)
					 System.out.print("Two ");
					 else if(temp==3)
					 System.out.print("Three ");
					 else if(temp==4)
					 System.out.print("Four ");
					 else if(temp==5)
					 System.out.print("Five ");
					 else if(temp==6)
					 System.out.print("Six ");
					 else if(temp==7)
					 System.out.print("Seven ");
					 else if(temp==8)
					 System.out.print("Eight ");
					 else if(temp==9)
					 System.out.print("Nine ");
			 
             if(div==1000 && temp!=0)
                    { System.out.print("Thousand ");
					  count=1;}
			if(div==100 && temp!=0)
			         { System.out.print("Hundred ");
					  count=2;}
			 }
			 if(div==10)
			 {       count=3;
				if(temp==1)
				{
			if(number==11)
			{System.out.print("Eleven ");
			 break;}
			 else if(number==12)
			 {System.out.print("Twelve ");
			 break;}
			 else if(number==13)
			 {System.out.print("Thirteen ");
			 break;}
			 else if(number==14)
			 {System.out.print("Fourteen ");
			 break;}
			 else if(number==15)
			 {System.out.print("Fifteen ");
			 break;}
			 else if(number==16)
			 {System.out.print("Sixteen ");
			 break;}
			 else if(number==17)
			 {System.out.print("Seventeen ");
			 break;}
			 else if(number==18)
			 {System.out.print("Eighteen ");
			 break;}
			 else if(number==19)
			 {System.out.print("Nineteen ");
			 break;}
			 }
			 
			 if(temp==2)
			 System.out.print("Twenty ");
			 else if(temp==3)
			 System.out.print("Thirty ");
			 else if(temp==4)
			 System.out.print("Forty ");
			 else if(temp==5)
			 System.out.print("Fifty ");
			 else if(temp==6)
			 System.out.print("Sixty ");
			 else if(temp==7)
			 System.out.print("Seventy ");
			 else if(temp==8)
			 System.out.print("Eighty ");
			 else if(temp==9)
			 System.out.print("Ninety ");
			 }
			 
			 number=number%div;
			 div=div/10;
			 if(div==1 && number!=0 && (count==1 && count==2))
			       System.out.print("and ");
				   }}}}
			
					  
					 
         		 
