import java.util.Scanner;

public class Bigof3
{
     public static void main(String[] args)
     {
          int num1,num2,num3,temp;

          Scanner sc=new Scanner(System.in);
         
          System.out.println("Enter first number");
          num1=sc.nextInt();

          System.out.println("Enter second number");
          num2=sc.nextInt();

          System.out.println("Enter third number");
          num3=sc.nextInt();

          if(num1>num2) 
             temp=num1;

          else
              temp=num2;
          
       
          if(temp>num3)
              System.out.println("Biggest number is:" + temp);  
          
          else
             System.out.println("Biggest number is:" + num3); 

       }   
}