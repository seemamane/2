import java.util.Scanner;

public class DigitalFormat
{
     public static void main(String[] args)
     {
	      int row=5,col=5,i,j,number;
		  
		  Scanner sc=new Scanner(System.in);
         
          System.out.println("Enter number");
          number=sc.nextInt();
		  
		  for(i=0;i<row;i++)
		  
		  { for(j=0;j<col;j++)
		  
	        {

			    if(number==3)
				{  if(i%2==0 || j==col-1)
		           System.out.print("*");
				   else
				   System.out.print(" ");
			    }
				else if(number==1)
				{  if(j==col-1)
				   System.out.print("*");
				   else
				   System.out.print(" ");
			    }
			    else if(number==7)
				{  if(i==0 || j==col-1)
				   System.out.print("*");
				   else
				   System.out.print(" ");
				}  
				else if(number==8)
				{  if(i%2==0 || j==0 || j==col-1)
				   System.out.print("*");
				   else
				   System.out.print(" ");
				}  
				else if(number==6)
				{  if(i%2==0 || j==0 || (i==row-2 && j==col-1))
				   System.out.print("*");
				   else
				   System.out.print(" ");
				}  
				else if(number==9)
				{  if(i%2==0 || j==col-1 || (i==1 && j==0))
				   System.out.print("*");
				   else
				   System.out.print(" ");
				}  
				else if(number==2)
				{  if(i%2==0 ||  (i==1 && j==col-1) || (i==row-2 && j==0))
				   System.out.print("*");
				   else
				   System.out.print(" ");
				}  
				else if(number==4)
				{  if(i==2 || j==col-1 ||(j==0 &&(i==0 || i==1)))
				   System.out.print("*");
				   else
				   System.out.print(" ");
				}  
				else if(number==5)
				{  if(i%2==0 ||  (i==1 && j==0) || (i==row-2 && j==col-1))
				   System.out.print("*");
				   else
				   System.out.print(" ");
				}  
				else if(number==0)
				{  if(i==0 || i==row-1 || j==0 || j==col-1)
				   System.out.print("*");
				   else
				   System.out.print(" ");
				}  
			}  System.out.println();
		  }	 
	 }	   
}		   
			 
			 
		
			 