import java.util.Scanner;

public class Circle
{
    public static void main(String[] args)
    {  float radius;
       final float pi=3.14f;
    
       Scanner sc=new Scanner(System.in);

       System.out.println("Enter radius:");
       radius=sc.nextFloat();

       Suystem.out.println("Area :" + (pi*radius*radius));
    }
}



