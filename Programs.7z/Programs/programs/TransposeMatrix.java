import java.util.Scanner;
 
class TransposeMatrix
{
   public static void main(String args[])
   {
      int row, col, i, d;
 
      Scanner in = new Scanner(System.in);
      System.out.println("Enter the number of rows and columns of matrix");
      row = in.nextInt();
      col = in.nextInt();
 
      int matrix[][] = new int[row][col];
 
      System.out.println("Enter the elements of matrix");
 
      for ( i = 0 ; i < row ; i++ )
         for ( d = 0 ; d < col ; d++ )
            matrix[i][d] = in.nextInt();
 
      int transpose[][] = new int[col][row];
 
      for ( i = 0 ; i < row ; i++ )
      {
         for ( d = 0 ; d < col ; d++ )               
            transpose[d][i] = matrix[i][d];
      }
 
      System.out.println("Transpose of entered matrix:-");
 
      for ( i = 0 ; i < col ; i++ )
      {
         for ( d = 0 ; d < row ; d++ )
               System.out.print(transpose[i][d]+"\t");
 
         System.out.print("\n");
      }
   }
}