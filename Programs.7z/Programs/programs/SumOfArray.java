import java.util.Scanner;

public class SumofArray
{
   public static void main(String[] args)
   {
     Scanner sc=new Scanner(System.in);
	 
	 final int SIZE=5;
	 int sum=0;
	 
     int arr[]=new int[SIZE];
     System.out.println("Enter 5 elements");
	 for(int i=0;i<SIZE;i++)
     arr[i]=sc.nextInt();
	 
	 for(int i=0;i<arr.length;i++)
	 sum+=arr[i];
	 
	 System.out.println("sum=:" + sum);
	 
	}
}	
	