package flp.cap.demo;
import java.util.Scanner;
import java.util.Date;
import java.lang.Math;

public class CalculateAge {
	
	private int date,month,year;
	private String str;
	
	public void getDob() {
		
		Scanner sc=new Scanner(System.in);
		
	/*	System.out.println("Enter Date Of Birth");
		date=sc.nextInt();
		
		System.out.println("Enter Month");
		month=sc.nextInt();
		
		System.out.println("Enter Enter Year");
		year=sc.nextInt();*/
		
		System.out.println("Enter Date Of Birth");
		System.out.println("Enter date-month in words-year");
		str=sc.next();
		
	}
	
	public void calcAge() {
		
		Date dob=new Date(str);
		Date currentDate=new Date();
		
		System.out.println("Current Date: " + currentDate);
		
		if(dob.getMonth()<=currentDate.getMonth() && dob.getDate()<=currentDate.getDate()) {
		year=currentDate.getYear()-dob.getYear();
		month=currentDate.getMonth()-dob.getMonth();
		date=currentDate.getDate()-dob.getDate();
		
		System.out.println("Age is :" + year + "years " + month + "months " + date + "days" );
		}
		
		else if(dob.getMonth()>currentDate.getMonth() && dob.getDate()<=currentDate.getDate()) {
			year=currentDate.getYear()-dob.getYear()-1;
			month=(currentDate.getMonth()+12)-dob.getMonth();
			date=currentDate.getDate()-dob.getDate();
			
			System.out.println("Age is :" + year + "years " + month + "months " + date + "days" );
			}
		
		else if(dob.getMonth()>currentDate.getMonth() && dob.getDate()>currentDate.getDate()) {
			year=currentDate.getYear()-dob.getYear()-1;
			month=(currentDate.getMonth()+11)-dob.getMonth();
			date=(currentDate.getDate()+31)-dob.getDate();
			
			System.out.println("Age is :" + year + "years " + month + "months " + date + "days" );
		}
		
		else if(dob.getMonth()<currentDate.getMonth() && dob.getDate()>currentDate.getDate()) {
			year=currentDate.getYear()-dob.getYear();
			month=currentDate.getMonth()-dob.getMonth();
			date=(currentDate.getDate()+31)-dob.getDate();
			
			System.out.println("Age is :" + year + "years " + month + "months " + date + "days" );
		}
		
		else if(dob.getMonth()==currentDate.getMonth() && dob.getDate()>currentDate.getDate()) {
			year=currentDate.getYear()-dob.getYear()-1;
			month=(currentDate.getMonth()+11)-dob.getMonth();
			date=(currentDate.getDate()+31)-dob.getDate();
			
			System.out.println("Age is :" + year + "years " + month + "months " + date + "days" );
		}
		
	}
	
}
