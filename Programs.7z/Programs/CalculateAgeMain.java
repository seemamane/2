package flp.cap.demo;

public class CalculateAgeMain {

	public static void main(String[] args) {
		
		CalculateAge c=new CalculateAge();
		c.getDob();
		c.calcAge();

	}

}
