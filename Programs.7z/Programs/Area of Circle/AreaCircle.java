public class AreaCircle
{
 public static void main (String args[])
  {
    float r1= 2.5f;
    final float pi= 3.14f;
    System.out.println("Area is"+ (r1*pi*pi));
}
}